﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataEntityLayer
{
    public class RequestMoreMedicine
    {
        public string RequestId { get; set; }
        public string MedicineId { get; set; }
        public int Dosage { get; set; }
        public int NumberOfMedicine { get; set; }
        public string Branch { get; set; }
        public int BranchAdminId { get; set; }
       
    }
}
