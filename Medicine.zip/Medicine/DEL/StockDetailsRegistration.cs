﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataEntityLayer
{
    public class StockDetailsRegistration
    {
        public string StockId { get; set; }
        public DateTime RegistrationDate { get; set; }
        public string MedicineId { get; set; }
        public int BranchAdminId { get; set; }
        public int NumberOfStrips { get; set; }
        public string Description { get; set; }
    }
}
