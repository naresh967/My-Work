﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using DataEntityLayer;

namespace BusinessLogicLayer
{
    public class MedicineRequestBusinessLogicLayer
    {
        MedicineRequestDataAccessLayer MedicineRequest = new MedicineRequestDataAccessLayer();

        public RequestMoreMedicine DisplayMedicineRequest(Object obj)
        {
            return MedicineRequest.Display(obj);
        }
        public bool DeleteMedicineRequest(Object RequestId)
        {
            if (MedicineRequest.Delete(RequestId))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool UpdateStatus(Object RequestId, Object Status)
        {
            if (MedicineRequest.UpdateStatus(RequestId, Status))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool InsertRequest(RequestMoreMedicine RequestMoreMedicines)
        {
            if (MedicineRequest.InsertRequest(RequestMoreMedicines))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
