﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using DataEntityLayer;

namespace BusinessLogicLayer
{
    public class BranchAdminBusinessLogicLayer
    {
       
        InterfaceDataAccessLayer<BranchAdminRegistration> GenericBranchAdmin = new BranchAdminDataAccessLayer();



        public bool InsertBranchAdmin(BranchAdminRegistration BranchAdminRegistration)
        {
            return GenericBranchAdmin.Insert(BranchAdminRegistration);
        }


        public string GetById(Object UserName, Object Password)
        {
            try
            {
                BranchAdminDataAccessLayer BranchAdminDataAccessLayer = new BranchAdminDataAccessLayer();
                string str;
                str = BranchAdminDataAccessLayer.Getbyid(UserName, Password).ToString();
                return str;
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }
       

        

    }
}
