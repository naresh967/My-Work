﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataEntityLayer;
using DataAccessLayer;

namespace BusinessLogicLayer
{
    public class StockDetailBusinessLogicLayer
    {
        StockDetailsRegistration md = new StockDetailsRegistration();
        InterfaceDataAccessLayer<StockDetailsRegistration> md1 = new StockDetailDataAccessLayer();
        public bool InsertMedicineDetail(StockDetailsRegistration md)
        {
            return md1.Insert(md);
        }

    }
}
