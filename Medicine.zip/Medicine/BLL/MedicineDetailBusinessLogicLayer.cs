﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using DataEntityLayer;

namespace BusinessLogicLayer
{
    public class MedicineDetailBusinessLogicLayer
    {
        InterfaceDataAccessLayer<MedicineDetailsRegistration> md1 = new MedicineDetailDataAccessLayer();

        public bool InsertMedicineDetail(MedicineDetailsRegistration MedicineDetail)
        {
            return md1.Insert(MedicineDetail);
        }      
        
   }
}
