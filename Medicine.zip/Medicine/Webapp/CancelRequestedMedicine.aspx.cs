﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogicLayer;
using DataEntityLayer;
using DataAccessLayer;
public partial class CancelRequestedMedicine : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session == null || Session["Fname"] == null || Session["BAI"] == null || Session["Fname"] == string.Empty || Session["BAI"] == string.Empty)
        {
            Response.Redirect("Login.aspx");
        }
        if (!Page.IsPostBack)
        {
            SqlDataSource2.SelectCommand = "select Request_Id from MedicineRequest where Status='Pending' and Branch_Admin_Id=" + Session["BAI"].ToString() + "";
            ddlRequest.DataBind();
            try
            {
                if (ddlRequest.Items.Count > 0)
                {
                    SqlDataSource1.SelectCommand = "select * from MedicineRequest where Request_Id='" + ddlRequest.Items[0].Text + "' and Branch_Admin_Id=" + Session["BAI"].ToString() + "";
                }
                else
                {
                    SqlDataSource1.SelectCommand = null;
                }
            }
            catch (Exception ex) { };
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlDataSource1.SelectCommand = "select * from MedicineRequest where Request_Id='" + ddlRequest.SelectedItem.Text + "'";
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        MedicineRequestBusinessLogicLayer CancelRequest = new MedicineRequestBusinessLogicLayer();
        if (CancelRequest.UpdateStatus(ddlRequest.SelectedItem.Text,"Cancelled"))
        {
            lblCancelResponse.Text="Request has been cancelled";
            Response.AddHeader("REFRESH", "5;URL=CancelRequestedMedicine.aspx");
        }
        else
        {
            lblCancelResponse.Text = "Error!";
        }
        
    }
}