﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MedicineRequest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session == null || Session["Fname"] == null || Session["BAI"] == null || Session["Fname"] == string.Empty || Session["BAI"] == string.Empty)
        {
            Response.Redirect("Login.aspx");
        }
        if (!Page.IsPostBack)
        {
            SqlDataSource1.SelectCommand = "select * from MedicineRequest where Branch_Admin_Id=" + Session["BAI"].ToString() + "";
            
        }
    }

    protected void btnCanMed_Click(object sender, EventArgs e)
    {
        Response.Redirect("CancelRequestedMedicine.aspx");
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}