﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataEntityLayer;
using BusinessLogicLayer;

public partial class BranchAdminRegister : System.Web.UI.Page
{
    public static void ClearTextBoxes(Control p1)
    {
        foreach (Control ctrl in p1.Controls)
        {
            if (ctrl is TextBox)
            {
                TextBox t = ctrl as TextBox;

                if (t != null)
                {
                    t.Text = String.Empty;
                }
            }
            else if (ctrl is DropDownList)
            {
                DropDownList d = ctrl as DropDownList;
                if (d != null)
                {
                    d.ClearSelection();
                }
            }
            else
            {
                if (ctrl.Controls.Count > 0)
                {
                    ClearTextBoxes(ctrl);
                }
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
      
    }
    protected void txtRegister_Click(object sender, EventArgs e)
    {
        BranchAdminBusinessLogicLayer BranchAdmin = new BranchAdminBusinessLogicLayer();
        BranchAdminRegistration BranchAdminRegistration = new BranchAdminRegistration();

        BranchAdminRegistration.FirstName = txtFirstName.Text;
        BranchAdminRegistration.LastName = txtLastName.Text;
        BranchAdminRegistration.PresentAddress = txtPresentAddress.Text;
        BranchAdminRegistration.PermanentAddress = txtPermanentAddress.Text;
        BranchAdminRegistration.Password = txtPassword.Text;
        BranchAdminRegistration.State = ddlState.SelectedItem.Text;
        BranchAdminRegistration.Country = ddlCountry.SelectedItem.Text;
        BranchAdminRegistration.EmailAddress = txtEmail.Text;
        BranchAdminRegistration.Gender = ddlGender.SelectedItem.Text;
        BranchAdminRegistration.MaritalStatus = ddlMaritalStatus.SelectedItem.Text;
        BranchAdminRegistration.ContactNumber = txtContactNumber.Text;
        BranchAdminRegistration.DateOfBirth = DateTime.Parse(txtDateOfBirth.Text);
        BranchAdminRegistration.IdProofType = lblPrefix.Text + txtIDNo.Text;

        if (BranchAdmin.InsertBranchAdmin(BranchAdminRegistration))
         {
             lblPagefb.Text = "Branch Admin Details Registered Successfully!";             
             BranchAdminRegister.ClearTextBoxes(Page);
         }

         
    }

    protected void ddlIdProofType_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblPrefix.Text = ddlIdProofType.SelectedValue;
    }
}