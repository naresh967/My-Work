﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using BusinessLogicLayer;

public partial class Admin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session == null || Session["Fname"] == null || Session["BAI"] == null || Session["Fname"] == string.Empty || Session["BAI"] == string.Empty)
        {
            Response.Redirect("Login.aspx");
        }
    }


    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        MedicineRequestBusinessLogicLayer MedicineRequest = new MedicineRequestBusinessLogicLayer();
        switch (Session["flag"].ToString())
        {
            case "Rejected":
                if (MedicineRequest.UpdateStatus(GridView1.SelectedRow.Cells[0].Text, Session["flag"].ToString()))
                {
                    Session["RID"] = GridView1.SelectedRow.Cells[0].Text;

                    Response.AddHeader("REFRESH", "5;URL=Admin.aspx");
                    lblResult.Text = string.Format("{0} id is Rejected", Session["RID"].ToString());

                }
                else
                {
                    Response.Redirect("Admin.aspx");
                    lblResult.Text = "Error!";

                }
                break;
            case "Approved":
                if (MedicineRequest.UpdateStatus(GridView1.SelectedRow.Cells[0].Text, Session["flag"].ToString()))
                {
                    Session["RID"] = GridView1.SelectedRow.Cells[0].Text;

                    Response.AddHeader("REFRESH", "5;URL=Admin.aspx");
                    lblResult.Text = string.Format("{0} id is Approved", Session["RID"].ToString());

                }
                else
                {
                    Response.Redirect("Admin.aspx");
                    lblResult.Text = "Error!";

                }
                break;
            default:
                lblResult.Text = "default Error!";
                break;
        }
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {

        Session["flag"] = "Rejected";


    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Session["flag"] = "Approved";


    }
}