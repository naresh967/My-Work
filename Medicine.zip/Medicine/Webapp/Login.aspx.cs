﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogicLayer;
using DataAccessLayer;


public partial class Login : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            lbloginerror.Text = string.Empty;
        }
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        lbloginerror.Text = string.Empty;
        BranchAdminBusinessLogicLayer BranchAdminLogin = new BranchAdminBusinessLogicLayer();
        string login = txtUserName.Text;
        string password = txtLoginPassword.Text;

        string LoginResult = BranchAdminLogin.GetById(login, password);


        if (LoginResult != string.Empty)
        {
            Session["Fname"] = txtUserName.Text;
            string[] LoginResultSplit = LoginResult.Split(' ');
            Session["BAI"] = LoginResultSplit[1];
            if (LoginResultSplit[0] == txtUserName.Text)
            {
                Response.Redirect("BranchAdminDashboard.aspx");
            }
            else
            {

            }


        }
        else if (txtUserName.Text == "admin" && txtLoginPassword.Text == "admin")
        {
            Session["Fname"] = "Admin";
            Session["BAI"] = "Admin";
            Response.Redirect("Admin.aspx");

        }
        else
        {
            lbloginerror.Text = "Invalid UserName or Password !!!";
        }

    }
}