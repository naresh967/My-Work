﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataEntityLayer;
using BusinessLogicLayer;
using DataAccessLayer;

public partial class MedicineDetailRegister : System.Web.UI.Page
{
  
    protected void Page_Load(object sender, EventArgs e)
    {
        rvManDate.MaximumValue = DateTime.Now.ToString("MM/dd/yyyy");
        rvManDate.MinimumValue = "01/01/1910";
        rvExpDate.MaximumValue = "01/01/3020";
        rvExpDate.MinimumValue = DateTime.Now.AddDays(1).ToString("MM/dd/yyyy");

        if (Session == null || Session["Fname"] == null || Session["BAI"] == null || Session["Fname"] == string.Empty || Session["BAI"] == string.Empty)
        {
            Response.Redirect("Login.aspx");
        }
        txtRegDate.Text = DateTime.Now.Date.ToString("yyyy-MM-dd");
    }

    protected void btnRegister_Click1(object sender, EventArgs e)
    {
        MedicineDetailBusinessLogicLayer MedicineDetail = new MedicineDetailBusinessLogicLayer();
        MedicineDetailsRegistration MedicineDetailsRegistration = new MedicineDetailsRegistration();

        MedicineDetailsRegistration.RegistrationDate = DateTime.Parse(txtRegDate.Text);
        MedicineDetailsRegistration.MedicineName = txtMedName.Text;
        MedicineDetailsRegistration.NumberOfMedicine = int.Parse(txtNMed.Text);
        MedicineDetailsRegistration.ManufacturedDate = DateTime.Parse(txtManDate.Text);
        MedicineDetailsRegistration.ExpiryDate = DateTime.Parse(txtExpDate.Text);
        MedicineDetailsRegistration.Price = int.Parse(txtPrice.Text);
        MedicineDetailsRegistration.Description = txtDesc.Text;
        if (MedicineDetail.InsertMedicineDetail(MedicineDetailsRegistration))
        {
            lblRegSuc.Text = "Medicine Registered successfully!";
        }
        else
        {
            lblRegSuc.Text = "Failed";
        }

    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        //MedicineDetailRegister.ClearTextBoxes(Page);

        lblRegSuc.Text = string.Empty;
        txtMedName.Text = string.Empty;
        txtNMed.Text = string.Empty;
        txtManDate.Text = string.Empty;
        txtExpDate.Text = string.Empty;
        txtPrice.Text = string.Empty;
        txtDesc.Text = string.Empty;

    }
}