﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using DataEntityLayer;
using BusinessLogicLayer;


public partial class StockRegistration : System.Web.UI.Page
{
    private System.Drawing.Color ff0000;
    public static void ClearTextBoxes(Control p1)
    {
        foreach (Control ctrl in p1.Controls)
        {
            if (ctrl is TextBox)
            {
                TextBox textbox = ctrl as TextBox;

                if (textbox != null)
                {
                    textbox.Text = String.Empty;
                }
            }
            else if (ctrl is DropDownList)
            {
                DropDownList Dropdown = ctrl as DropDownList;
                if (Dropdown != null)
                {
                    Dropdown.ClearSelection();
                }
            }
            else
            {
                if (ctrl.Controls.Count > 0)
                {
                    ClearTextBoxes(ctrl);
                }
            }
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session == null || Session["Fname"] == null || Session["BAI"] == null || Session["Fname"] == string.Empty || Session["BAI"] == string.Empty)
        {
            Response.Redirect("Login.aspx");
        }
        txtRegistrationDate.Text = DateTime.Now.Date.ToString("yyyy-MM-dd");
        txtBId.Text = Session["BAI"].ToString();
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        StockRegistration.ClearTextBoxes(Page);
        
    }
    protected void btnregister_Click(object sender, EventArgs e)
    {
        StockDetailsRegistration StockDetailsRegistrationByAdmin = new StockDetailsRegistration();
        StockDetailBusinessLogicLayer StockDetail = new StockDetailBusinessLogicLayer();
        StockDetailsRegistrationByAdmin.RegistrationDate = DateTime.Parse(txtRegistrationDate.Text);
        StockDetailsRegistrationByAdmin.MedicineId = ddlMId.SelectedItem.Text;
        StockDetailsRegistrationByAdmin.BranchAdminId = Convert.ToInt32(txtBId.Text);
        StockDetailsRegistrationByAdmin.NumberOfStrips = Convert.ToInt32(txtNumberOfStrips.Text);
        StockDetailsRegistrationByAdmin.Description = txtDescription.Text;
        if (StockDetail.InsertMedicineDetail(StockDetailsRegistrationByAdmin))
        {
            lblStockResult.Text = "Stock details updated successfully!";
            StockRegistration.ClearTextBoxes(Page);
        }
        else
        {
            lblStockResult.ForeColor = ff0000;
            lblStockResult.Text = "Error!";
        }
    }



}