﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminDashboard : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session == null)
        {
            Response.Redirect("Login.aspx");
        }
        lblDisplayName.Text = "UserName : " + Session["Fname"].ToString().ToUpper();
        lblBAI.Text = "ID : " + Session["BAI"].ToString();
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Session["Fname"] = null;
        Response.Redirect("Login.aspx");
    }
}
