﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataEntityLayer;
using BusinessLogicLayer;
using DataAccessLayer;

public partial class RequestMoreMedicine : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session == null || Session["Fname"] == null || Session["BAI"] == null || Session["Fname"] == string.Empty || Session["BAI"] == string.Empty)
        {
            Response.Redirect("Login.aspx");
        }
    }
    protected void btnRequest_Click(object sender, EventArgs e)
    {
        MedicineRequestBusinessLogicLayer MedicineRequestBusinessLayer = new MedicineRequestBusinessLogicLayer();
        DataEntityLayer.RequestMoreMedicine RequestMoreMedicineByAdministrator = new DataEntityLayer.RequestMoreMedicine();
        RequestMoreMedicineByAdministrator.MedicineId = ddlMedID.SelectedItem.Text;
        RequestMoreMedicineByAdministrator.Dosage = Convert.ToInt32(txtDose.Text);
        RequestMoreMedicineByAdministrator.NumberOfMedicine = Convert.ToInt32(txtNMed.Text);
        RequestMoreMedicineByAdministrator.Branch = txtBranch.Text;
        RequestMoreMedicineByAdministrator.BranchAdminId = Convert.ToInt32(Session["BAI"].ToString());

        if (MedicineRequestBusinessLayer.InsertRequest(RequestMoreMedicineByAdministrator))
        {
            lblReqResult.Text = "Request for Medicine is Successful!";
        }
        else
        {
            lblReqResult.Text = "Failed!";
        }
    }
    
}