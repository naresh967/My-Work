﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataEntityLayer;
using System.Data.SqlClient;

namespace DataAccessLayer
{
    public class StockDetailDataAccessLayer : InterfaceDataAccessLayer<StockDetailsRegistration>
    {
        SqlConnection sqlcon = new SqlConnection(DataAccessLayer.Properties.Settings2.Default.conStr);
        SqlCommand cmd;
        SqlDataReader DataReader;


        bool InterfaceDataAccessLayer<StockDetailsRegistration>.Insert(StockDetailsRegistration StockDetail)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "Select count(*) AS TotalStockCount from StockDetailsRegistration";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                DataReader = cmd.ExecuteReader();
                DataReader.Read();
                int count = Convert.ToInt32(DataReader["TotalStockCount"].ToString());
              
                count++;
                string StockId = "ST" + count.ToString("0000");
                StockDetail.StockId = StockId;
                
                if (sqlcon.State == System.Data.ConnectionState.Open)
                {
                    sqlcon.Close();
                }



                cmd = new SqlCommand();
                cmd.Connection = sqlcon;

                cmd.CommandText = "InsertStockDetail @StockId='" + StockDetail.StockId + "', @RegistrationDate='" + StockDetail.RegistrationDate + "', @MedicineId = '" + StockDetail.MedicineId + "', @BranchAdminId = '" + StockDetail.BranchAdminId + "', @NumberOfStrips=" + StockDetail.NumberOfStrips + ",@Description ='" + StockDetail.Description + "'";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                int n=cmd.ExecuteNonQuery();

                
                if (n > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }
    }
}
