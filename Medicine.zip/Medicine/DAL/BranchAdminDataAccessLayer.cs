﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataEntityLayer;
using System.Data.SqlClient;


namespace DataAccessLayer
{
    public class BranchAdminDataAccessLayer : InterfaceDataAccessLayer<BranchAdminRegistration>
    {
        SqlConnection sqlcon = new SqlConnection(DataAccessLayer.Properties.Settings2.Default.conStr);
        SqlCommand cmd;
        SqlDataReader dr;

        bool InterfaceDataAccessLayer<BranchAdminRegistration>.Insert(BranchAdminRegistration ba)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;

                int now = int.Parse(DateTime.Now.ToString("yyyyMMdd"));
                int dob = int.Parse(ba.DateOfBirth.ToString("yyyyMMdd"));
                int age = (now - dob) / 10000;

                if (age < 18)
                    ba.Status = "Minor";
                else if (age >= 18 && age <= 60)
                    ba.Status = "Normal";
                else
                    ba.Status = "Senior";

                cmd.CommandText = "InsertBranchAdmin @FirstName ='" + ba.FirstName + "', @LastName='" + ba.LastName + "', @PresentAddress = '" + ba.PresentAddress + "', @PermanentAddress='" + ba.PermanentAddress + "',@Password ='" + ba.Password + "', @State='" + ba.State + "', @Country='" + ba.Country + "',@EmailAddress='" + ba.EmailAddress + "', @Gender ='" + ba.Gender + "', @MaritalStatus ='" + ba.MaritalStatus + "',@ContactNumber='" + ba.ContactNumber + "',@DateOfBirth='" + ba.DateOfBirth + "',@IdProofType ='" + ba.IdProofType + "', @Status='"+ ba.Status +"'";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public string Getbyid(Object UserName, Object Password)
        {

            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;               
                cmd.CommandText = "GetByIdRegistration @FirstName='" + UserName + "',@Password='" + Password + "'";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();

                dr.Read();
                string s = dr["Fname"].ToString() + " " + dr["BAI"].ToString();
                return s;

            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                sqlcon.Close();
            }

        }


    }
}
