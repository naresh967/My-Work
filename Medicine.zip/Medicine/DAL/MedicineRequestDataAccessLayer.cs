﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataEntityLayer;
using System.Data.SqlClient;

namespace DataAccessLayer
{
     public class MedicineRequestDataAccessLayer
    {
        SqlConnection sqlcon = new SqlConnection(DataAccessLayer.Properties.Settings2.Default.conStr);
        SqlCommand cmd;
        SqlDataReader DataReader;
        RequestMoreMedicine mr = new RequestMoreMedicine();

        public bool InsertRequest(RequestMoreMedicine MedReq)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "SELECT count(*) as medcount FROM MedicineRequest";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                DataReader = cmd.ExecuteReader();
                DataReader.Read();
                int count = Convert.ToInt32(DataReader["medcount"].ToString());
               
                count++;
                string reqID = "REQ" + count.ToString("000");
                MedReq.RequestId = reqID;
               
                if (sqlcon.State == System.Data.ConnectionState.Open)
                {
                    sqlcon.Close();
                }
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "InsertMedicineRequest @RequestId = '" + MedReq.RequestId + "', @MedicineId ='" + MedReq.MedicineId + "', @Dosage =" + MedReq.Dosage + ", @NumberOfMedicine=" + MedReq.NumberOfMedicine + ", @Branch='" + MedReq.Branch + "', @BranchAdminId=" + MedReq.BranchAdminId + "";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                int n = cmd.ExecuteNonQuery();
                if (n > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public RequestMoreMedicine Display(Object DisplayReq)
        {
          
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = " SelectMedicineRequest @RequestId= '" + DisplayReq + "'";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                DataReader = cmd.ExecuteReader();

                if (DataReader.HasRows == true)
                {
                    DataReader.Read();
                    mr.RequestId = (DataReader["RequestId"]).ToString();
                    mr.MedicineId = (DataReader["MedicineId"]).ToString();
                    mr.Dosage = Convert.ToInt32(DataReader["Dosage"]);
                    mr.NumberOfMedicine = Convert.ToInt32(DataReader["NumberOfMedicine"]);
                    mr.Branch = (DataReader["Branch"]).ToString();
                    return mr;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                sqlcon.Close();
            }
        }
        
         public bool Delete(Object DelReq)
        {
           
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "DeleteMedicineRequest @RequestId= '" + DelReq + "'";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                int n= cmd.ExecuteNonQuery();
                if (n <0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

         public bool UpdateStatus(Object ReqId,Object Status)
         {
             try
             {
                 cmd = new SqlCommand();
                 cmd.Connection = sqlcon;
                 cmd.CommandText = "UpdateMedicineRequest @RequestId= '" + ReqId + "',@Status='"+ Status +"'";
                 if (sqlcon.State == System.Data.ConnectionState.Closed)
                 {
                     sqlcon.Open();
                 }
                 int n = cmd.ExecuteNonQuery();
                 if (n > 0)
                 {
                     return true;
                 }
                 else
                 {
                     return false;
                 }

             }
             catch (Exception ex)
             {
                 return false;
             }
             finally
             {
                 sqlcon.Close();
             }

         }
     }

}
