﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataEntityLayer;
using System.Data.SqlClient;


namespace DataAccessLayer
{
    public class MedicineDetailDataAccessLayer : InterfaceDataAccessLayer<MedicineDetailsRegistration>
    {
        SqlConnection sqlcon = new SqlConnection(DataAccessLayer.Properties.Settings2.Default.conStr);
        SqlCommand cmd;
        SqlDataReader DataReader;

        bool InterfaceDataAccessLayer<MedicineDetailsRegistration>.Insert(MedicineDetailsRegistration MedicineDetail)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "SELECT count(*) as TotalMedCount FROM MedicineDetailsRegistration";
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                DataReader = cmd.ExecuteReader();
                DataReader.Read();
                int count = Convert.ToInt32(DataReader["TotalMedCount"].ToString());
                
                count++;
                string MedicineId = "M" + count.ToString("0000");
                MedicineDetail.MedicineTypeId = MedicineId;
                
                if (sqlcon.State == System.Data.ConnectionState.Open)
                {
                    sqlcon.Close();
                }
                cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "InsertMedicineDetail @MedicineTypeId = '" + MedicineDetail.MedicineTypeId + "',	@RegistrationDate='" + MedicineDetail.RegistrationDate + "', @MedicineName='" + MedicineDetail.MedicineName + "', @NumberOfMedicine=" + MedicineDetail.NumberOfMedicine + ",	@ManufacturedDate='" + MedicineDetail.ManufacturedDate + "', @ExpiryDate='" + MedicineDetail.ExpiryDate + "', @Price=" + MedicineDetail.Price + ",@Description ='" + MedicineDetail.Description + "'";                
                if (sqlcon.State == System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                int n=cmd.ExecuteNonQuery();
                if (n > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

    }
}
