function MenuFunc() {
  var x = document.getElementById("id_menubar");
  if (x.className === "menubar") {
    x.className += " responsive";
  } else {
    x.className = "menubar";
  }
}