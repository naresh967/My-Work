<html>
	<head>
		
		
		<link rel="stylesheet" type ="text/css" href="style.css">
		
	</head>
	<body>
		
		<p>Thank you for signing up for the Tropical Treats Weekly newsletter.
			
			We have added the following information to our files regarding your interests:
		</p>
		<div class= "main">
			Welcome <?php echo $_POST[name]; ?><br><br>
			Your email address is: <?php echo $_POST[email]; ?><br><br>
			Product Interests : <?php echo $_POST[product]; ?><br><br><br>
			Birthday :  <?php echo $_POST[date]; ?>
		</div>
		
		<input type="button" class= "buttonphp" value="Back" onclick="location ='index.html'"/>
		
		
		
	</body>
</html>